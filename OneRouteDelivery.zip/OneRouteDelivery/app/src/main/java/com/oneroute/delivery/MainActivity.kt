package com.oneroute.delivery

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF142A27)
private val Green = Color(0xFF176B5B)
private val Pale = Color(0xFFF3F7F5)
private val Orange = Color(0xFFFF8A24)
private val Red = Color(0xFFE64C4C)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { OneRouteApp() }
    }
}

data class DeliveryOrder(val platform: String, val address: String, val amount: Double)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OneRouteApp() {
    var tab by remember { mutableStateOf(0) }
    var orders by remember { mutableStateOf(listOf<DeliveryOrder>()) }
    var showAdd by remember { mutableStateOf(false) }
    var swiggyEarnings by remember { mutableStateOf("0") }
    var zomatoEarnings by remember { mutableStateOf("0") }
    var fuel by remember { mutableStateOf("0") }
    val context = LocalContext.current
    val total = (swiggyEarnings.toDoubleOrNull() ?: 0.0) + (zomatoEarnings.toDoubleOrNull() ?: 0.0)
    val net = total - (fuel.toDoubleOrNull() ?: 0.0)

    MaterialTheme(colorScheme = lightColorScheme(primary = Green, background = Pale, surface = Color.White)) {
        Scaffold(
            containerColor = Pale,
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("OneRoute", fontWeight = FontWeight.ExtraBold, fontSize = 22.sp, color = Ink)
                            Text("DELIVERY PARTNER COMPANION", fontSize = 9.sp, letterSpacing = 1.4.sp, color = Green)
                        }
                    },
                    actions = {
                        IconButton(onClick = { tab = 3 }) { Icon(Icons.Default.Settings, "Settings", tint = Ink) }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Pale)
                )
            },
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = { Icon(Icons.Default.Dashboard, null) }, label = { Text("Home") })
                    NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = { Icon(Icons.Default.Map, null) }, label = { Text("One Map") })
                    NavigationBarItem(selected = tab == 2, onClick = { tab = 2 }, icon = { Icon(Icons.Default.CurrencyRupee, null) }, label = { Text("Earnings") })
                    NavigationBarItem(selected = tab == 3, onClick = { tab = 3 }, icon = { Icon(Icons.Default.Tune, null) }, label = { Text("More") })
                }
            }
        ) { padding ->
            when (tab) {
                0 -> HomeScreen(Modifier.padding(padding), orders, total, net, { showAdd = true }, { tab = 1 })
                1 -> MapScreen(Modifier.padding(padding), orders, { showAdd = true }, {
                    val query = Uri.encode(orders.firstOrNull()?.address ?: "Hubballi, Karnataka")
                    context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/dir/?api=1&destination=$query")))
                })
                2 -> EarningsScreen(Modifier.padding(padding), swiggyEarnings, { swiggyEarnings = it }, zomatoEarnings, { zomatoEarnings = it }, fuel, { fuel = it }, total, net)
                else -> SettingsScreen(Modifier.padding(padding))
            }
        }
        if (showAdd) AddOrderDialog(onDismiss = { showAdd = false }, onAdd = { orders = orders + it; showAdd = false })
    }
}

@Composable
fun HomeScreen(modifier: Modifier, orders: List<DeliveryOrder>, total: Double, net: Double, add: () -> Unit, map: () -> Unit) {
    LazyColumn(modifier.fillMaxSize().padding(horizontal = 18.dp), verticalArrangement = Arrangement.spacedBy(14.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
        item {
            Surface(shape = RoundedCornerShape(24.dp), color = Green, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(20.dp)) {
                    Text("YOUR SHIFT, SIMPLIFIED", color = Color(0xFFBFE6D9), fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
                    Spacer(Modifier.height(8.dp))
                    Text("Two platforms.\nOne clear view.", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 32.sp)
                    Spacer(Modifier.height(14.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        PlatformChip("Swiggy", Orange)
                        PlatformChip("Zomato", Red)
                    }
                    Spacer(Modifier.height(18.dp))
                    Button(onClick = add, colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Green), shape = RoundedCornerShape(12.dp)) {
                        Icon(Icons.Default.Add, null); Spacer(Modifier.width(6.dp)); Text("Add delivery")
                    }
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                MetricCard("Today's earnings", "₹${money(total)}", "Both platforms", Modifier.weight(1f))
                MetricCard("Estimated net", "₹${money(net)}", "After fuel", Modifier.weight(1f))
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Text("Today's deliveries", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Ink, modifier = Modifier.weight(1f))
                Text("${orders.size} added", color = Green, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            }
        }
        if (orders.isEmpty()) item { EmptyOrders(add) }
        items(orders.size) { i -> OrderRow(orders[i], i + 1) }
        item {
            OutlinedButton(onClick = map, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                Icon(Icons.Default.Map, null); Spacer(Modifier.width(8.dp)); Text("View route on Google Maps")
            }
        }
        item { Text("Note: Live order syncing is not connected yet. Add deliveries manually until authorised platform integrations are available.", fontSize = 11.sp, color = Color(0xFF687773)) }
    }
}

@Composable
fun PlatformChip(name: String, color: Color) {
    Surface(color = color.copy(alpha = 0.18f), shape = RoundedCornerShape(8.dp)) {
        Row(Modifier.padding(horizontal = 10.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(7.dp).background(color, CircleShape)); Spacer(Modifier.width(6.dp))
            Text(name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        }
    }
}

@Composable
fun MetricCard(title: String, value: String, subtitle: String, modifier: Modifier = Modifier) {
    Surface(modifier, color = Color.White, shape = RoundedCornerShape(18.dp), shadowElevation = 1.dp) {
        Column(Modifier.padding(15.dp)) {
            Text(title, color = Color(0xFF667671), fontSize = 12.sp)
            Spacer(Modifier.height(8.dp)); Text(value, color = Ink, fontWeight = FontWeight.ExtraBold, fontSize = 23.sp)
            Spacer(Modifier.height(4.dp)); Text(subtitle, color = Green, fontSize = 11.sp)
        }
    }
}

@Composable
fun EmptyOrders(add: () -> Unit) {
    Surface(color = Color.White, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Default.LocalShipping, null, tint = Green, modifier = Modifier.size(40.dp))
            Spacer(Modifier.height(10.dp)); Text("No deliveries added yet", color = Ink, fontWeight = FontWeight.Bold)
            Text("Add an address to start planning your route.", color = Color.Gray, fontSize = 12.sp)
            Spacer(Modifier.height(12.dp)); TextButton(onClick = add) { Text("Add first delivery") }
        }
    }
}

@Composable
fun OrderRow(order: DeliveryOrder, index: Int) {
    Surface(color = Color.White, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(38.dp).background(if (order.platform == "Swiggy") Orange.copy(alpha = .15f) else Red.copy(alpha = .13f), CircleShape), contentAlignment = Alignment.Center) {
                Text("$index", color = Ink, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(order.platform, color = if (order.platform == "Swiggy") Orange else Red, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text(order.address, color = Ink, fontWeight = FontWeight.SemiBold, maxLines = 2)
            }
            Text("₹${money(order.amount)}", color = Green, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun MapScreen(modifier: Modifier, orders: List<DeliveryOrder>, add: () -> Unit, openMaps: () -> Unit) {
    Column(modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("One Route Map", color = Ink, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
        Text("Plan destinations from both platforms in one place.", color = Color(0xFF65756F))
        Surface(color = Color(0xFFE2EEE8), shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth().weight(1f)) {
            Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.Map, null, tint = Green, modifier = Modifier.size(58.dp))
                Spacer(Modifier.height(14.dp)); Text("Google Maps route hand-off", color = Ink, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text("${orders.size} saved stop(s)", color = Green)
                Spacer(Modifier.height(8.dp)); Text("This starter version opens Google Maps for a destination. In-app multi-stop mapping needs a Maps API key and route-planning setup.", color = Color(0xFF53645E), fontSize = 12.sp)
                Spacer(Modifier.height(18.dp)); Button(onClick = openMaps) { Text("Open Google Maps") }
            }
        }
        OutlinedButton(onClick = add, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(6.dp)); Text("Add delivery stop") }
    }
}

@Composable
fun EarningsScreen(modifier: Modifier, swiggy: String, setSwiggy: (String) -> Unit, zomato: String, setZomato: (String) -> Unit, fuel: String, setFuel: (String) -> Unit, total: Double, net: Double) {
    LazyColumn(modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
        item { Text("Earnings tracker", color = Ink, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold); Text("Enter today's figures to estimate take-home earnings.", color = Color.Gray) }
        item { MoneyField("Swiggy earnings (₹)", swiggy, setSwiggy, Orange) }
        item { MoneyField("Zomato earnings (₹)", zomato, setZomato, Red) }
        item { MoneyField("Fuel expense (₹)", fuel, setFuel, Green) }
        item { MetricCard("Combined earnings", "₹${money(total)}", "Swiggy + Zomato", Modifier.fillMaxWidth()) }
        item { Surface(color = Green, shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(20.dp)) { Text("ESTIMATED NET", color = Color(0xFFBFE6D9), fontSize = 12.sp); Text("₹${money(net)}", color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.ExtraBold); Text("Combined earnings minus fuel", color = Color.White.copy(alpha = .8f), fontSize = 12.sp) } } }
        item { Text("Figures are saved only while this screen is open in this prototype; persistent storage will be added in the next build.", color = Color.Gray, fontSize = 11.sp) }
    }
}

@Composable
fun MoneyField(label: String, value: String, onValue: (String) -> Unit, accent: Color) {
    OutlinedTextField(value = value, onValueChange = { onValue(it.filter { c -> c.isDigit() || c == '.' }) }, label = { Text(label) }, leadingIcon = { Icon(Icons.Default.CurrencyRupee, null, tint = accent) }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp))
}

@Composable
fun SettingsScreen(modifier: Modifier) {
    Column(modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Settings & connections", color = Ink, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
        Surface(color = Color.White, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                SettingRow(Icons.Default.DeliveryDining, "Swiggy connection", "Not connected — authorised access required", Orange)
                HorizontalDivider()
                SettingRow(Icons.Default.Restaurant, "Zomato connection", "Not connected — authorised access required", Red)
                HorizontalDivider()
                SettingRow(Icons.Default.Map, "Google Maps", "External navigation enabled", Green)
                HorizontalDivider()
                SettingRow(Icons.Default.Language, "Language", "English (Kannada can be added)", Green)
            }
        }
        Text("OneRoute is an independent companion concept and is not affiliated with Swiggy or Zomato. Never share platform passwords or OTPs with third-party apps.", color = Color(0xFF687773), fontSize = 12.sp)
    }
}

@Composable
fun SettingRow(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, detail: String, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = color, modifier = Modifier.size(27.dp)); Spacer(Modifier.width(12.dp))
        Column { Text(title, color = Ink, fontWeight = FontWeight.Bold); Text(detail, color = Color.Gray, fontSize = 11.sp) }
    }
}

@Composable
fun AddOrderDialog(onDismiss: () -> Unit, onAdd: (DeliveryOrder) -> Unit) {
    var platform by remember { mutableStateOf("Swiggy") }
    var address by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Add delivery", fontWeight = FontWeight.Bold) }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Platform")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = platform == "Swiggy", onClick = { platform = "Swiggy" }, label = { Text("Swiggy") })
                FilterChip(selected = platform == "Zomato", onClick = { platform = "Zomato" }, label = { Text("Zomato") })
            }
            OutlinedTextField(value = address, onValueChange = { address = it }, label = { Text("Delivery address") }, singleLine = false)
            OutlinedTextField(value = amount, onValueChange = { amount = it.filter { c -> c.isDigit() || c == '.' } }, label = { Text("Order payout (₹, optional)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
        }
    }, confirmButton = { Button(onClick = { if (address.isNotBlank()) onAdd(DeliveryOrder(platform, address.trim(), amount.toDoubleOrNull() ?: 0.0)) }, enabled = address.isNotBlank()) { Text("Add stop") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } })
}

fun money(value: Double): String = String.format(java.util.Locale.US, "%.0f", value)
